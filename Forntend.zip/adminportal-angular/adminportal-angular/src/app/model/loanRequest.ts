export class LoanRequest {
    id: number = 0;
    accountNumber: string = '';
    loanType:  string = '';
    loanAmount: string = '';
    date: string = '';
    status: string = '';
}