package com.admin;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import com.admin.controller.TranscationController;
import com.admin.dao.LoanRepository;
import com.admin.dao.TransferRepository;
import com.admin.dao.UserHistoryRepository;
import com.admin.model.Loan;
import com.admin.model.Transfer;
import com.admin.model.UserHistory;

public class TranscationControllerTest {

    @Test
    public void testTranscationDetails() {
        UserHistoryRepository mockUserHistoryRepo = mock(UserHistoryRepository.class);
        TranscationController transcationController = new TranscationController(
                mockUserHistoryRepo, mock(LoanRepository.class), mock(TransferRepository.class)
        );

        List<UserHistory> mockUserHistories = new ArrayList<>();
        when(mockUserHistoryRepo.findAll()).thenReturn(mockUserHistories);

        List<UserHistory> result = transcationController.TranscationDetails();

        assertEquals(mockUserHistories, result);
    }

    @Test
    public void testTransferDetails() {
        TransferRepository mockTransferRepo = mock(TransferRepository.class);
        TranscationController transcationController = new TranscationController(
                mock(UserHistoryRepository.class), mock(LoanRepository.class), mockTransferRepo
        );

        List<Transfer> mockTransfers = new ArrayList<>();
        when(mockTransferRepo.findAll()).thenReturn(mockTransfers);

        Iterable<Transfer> result = transcationController.TransferDetails();

        assertEquals(mockTransfers, result);
    }

    @Test
    public void testApproveLoan() {
        LoanRepository mockLoanRepo = mock(LoanRepository.class);
        TranscationController transcationController = new TranscationController(
                mock(UserHistoryRepository.class), mockLoanRepo, mock(TransferRepository.class)
        );

        int id = 1;
        Loan mockLoan = new Loan();
        mockLoan.setId(id);
        mockLoan.setAccountNumber("123456");
        mockLoan.setDate("2023-09-25");
        mockLoan.setLoanAmount(1000);
        mockLoan.setLoanType("Personal");
        mockLoan.setStatus("Approved");

        Optional<Loan> optionalLoan = Optional.of(mockLoan);
        when(mockLoanRepo.findById(id)).thenReturn(optionalLoan);
        when(mockLoanRepo.save(any(Loan.class))).thenReturn(mockLoan);

        ResponseEntity<Loan> result = transcationController.ApproveLoan(id, mockLoan);

        assertNotNull(result);
        assertEquals(200, result.getStatusCodeValue());

        Loan updatedLoan = result.getBody();
        assertEquals("123456", updatedLoan.getAccountNumber());
        assertEquals("2023-09-25", updatedLoan.getDate());
        assertEquals(1000.0, updatedLoan.getLoanAmount());
        assertEquals("Personal", updatedLoan.getLoanType());
        assertEquals("Approved", updatedLoan.getStatus());
    }

    // Similar tests for other methods...
}
