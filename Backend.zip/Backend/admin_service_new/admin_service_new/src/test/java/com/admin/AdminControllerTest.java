package com.admin;

import static org.junit.jupiter.api.Assertions.*;
import com.admin.service.impl.*;
import com.admin.controller.*;

import org.apache.commons.mail.EmailException;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.ArrayList;
import java.util.List;

public class AdminControllerTest {

	 @Test
	    public void testSetUserFeatures() {
	        AdminServiceImpl mockService = Mockito.mock(AdminServiceImpl.class);
	        MailServiceImpl mockMailService = Mockito.mock(MailServiceImpl.class);

	        AdminController adminController = new AdminController(mockService, mockMailService);

	        String username = "testUser";
	        int featureId = 1;

	        adminController.setUserFeatures(username, featureId);

	        Mockito.verify(mockService).setUserFeatures(username, featureId);
	    }

	 @Test
	 public void testAuthorizeUser() throws EmailException {
	     AdminServiceImpl mockService = Mockito.mock(AdminServiceImpl.class);
	     MailServiceImpl mockMailService = Mockito.mock(MailServiceImpl.class);

	     AdminController adminController = new AdminController(mockService, mockMailService);

	     String username = "testUser";

	     // Call the method
	     adminController.authorizeUser(username);

	     // Verify that the service method was called with the correct arguments
	     Mockito.verify(mockService).authorizeUser(username);

	     // Verify that the mailService method was called with the correct arguments
	     Mockito.verify(mockMailService).sendAuthorizedEmail(username);
	 }


    // Similarly, write tests for other methods

    // ...

    // You can write similar tests for other methods
}

