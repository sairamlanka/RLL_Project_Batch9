package com.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.admin.dao.YourEntityRepository;
import com.admin.model.YourEntity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class DownloadController {

    @Autowired
    private YourEntityRepository entityRepository;

    @GetMapping("/download")
    public ResponseEntity<byte[]> downloadFile() throws IOException {
        // Fetch data from the database
        List<YourEntity> entities = entityRepository.findAll();

        // Convert the data to a format suitable for your download
        byte[] fileContent = convertDataToByteArray(entities);

        // Build the response and return it
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "downloaded-file.ext");

        return new ResponseEntity<>(fileContent, headers, HttpStatus.OK);
    }

    private byte[] convertDataToByteArray(List<YourEntity> entities) throws IOException {
        // Example: Convert the data to a CSV format
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        for (YourEntity entity : entities) {
            String csvLine = entity.getId() + "," + entity.getAccount() + "," + entity.getAmount()  + "," + entity.getAction() + "\n";
            outputStream.write(csvLine.getBytes());
        }
        return outputStream.toByteArray();
    }
}
