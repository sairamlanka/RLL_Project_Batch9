package com.icinbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcinbankNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(IcinbankNewApplication.class, args);
	}

}
